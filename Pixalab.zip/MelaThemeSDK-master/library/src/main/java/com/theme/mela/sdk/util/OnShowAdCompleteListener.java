package com.theme.mela.sdk.util;

public interface OnShowAdCompleteListener {
    void onShowAdComplete();
}